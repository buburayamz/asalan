import axios from 'axios'; // Import Axios

// URL yang ingin Anda akses
const url = 'https://www.bilibili.tv/id/video/2009037660?bstar_from=bstar-web.ugc-video-detail.related-recommend.all';

// Menggunakan Axios untuk mengambil data dari URL
axios.get(url)
  .then(response => {
    // Menyimpan data yang diterima
    const data = response.data;
	
    // Mencetak data
	console.log("data", data);
	
	// ====================================================================================================================================================
	// Find the position of the title tag
	let titleStart = data.indexOf('",title:"') + '",title:"'.length;
	let titleEnd = data.indexOf('",pub_date:', titleStart);

	// Extract the title
	let title = data.substring(titleStart, titleEnd);
	
	// Truncate title if it exceeds 100 characters
	if (title.length > 200) {
		console.log("GAGAL PARSE PERTAMA (JUDUL), PERCOBAAN KEDUA");
		
		// Find the position of the title tag
		titleStart = data.indexOf('archive:{aid:m,cover:n,title:"') + 'archive:{aid:m,cover:n,title:"'.length;
		titleEnd = data.indexOf('",pub_date:', titleStart);

		// Extract the title
		title = data.substring(titleStart, titleEnd);
		
	}
	
	console.log("title : ", title);
	// ====================================================================================================================================================

	// ,stat:{views:"4.2K Ditonton",followers:"641 Pengikut",arcs:"47 Videos"
	
	// Find the position of the views tag
	const viewsStart = data.indexOf(',stat:{views:"') + ',stat:{views:"'.length;
	const viewsEnd = data.indexOf('",followers:"', viewsStart);

	// Find the position of the views tag
	const followersStart = data.indexOf(',followers:"') + ',followers:"'.length;
	const followersEnd = data.indexOf('",arcs:"', followersStart);

	// Extract the title
	const views = data.substring(viewsStart, viewsEnd);

	// Extract the title
	const followers = data.substring(followersStart, followersEnd);

	console.log("views : ", views);
	console.log("followers : ", followers);
	
	// ====================================================================================================================================================





	
  })
  .catch(error => {
    // Menangani kesalahan jika ada
    console.error('Error fetching data:', error);
  });
