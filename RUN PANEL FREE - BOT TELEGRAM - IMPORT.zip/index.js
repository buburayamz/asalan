// bot.js
import TelegramBot from 'node-telegram-bot-api';
import axios from 'axios'; // Import Axios


// Ganti 'TOKEN_BOT_ANDA' dengan token bot Anda dari BotFather
const token = '6975434079:AAH3UUu1C-j4AhDSy55uoFYrYPvAZxRoo3c';

// Inisialisasi bot
const bot = new TelegramBot(token, { polling: true });

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

const options = (vid, id) => {
	return {
		headers: {
			Origin: 'https://www.bilibili.tv',
			Referer: `https://www.bilibili.tv/id/video/${vid}?bstar_from=bstar-web.homepage.recommend.all`,
			Cookie: "mid=1971290613; DedeUserID=1971290613; DedeUserID__ckMd5=5cd0e460cad2918039586afe927132b5; SESSDATA=1fad3504,1731512002,88ade*5100f5; bili_jct=29a56853bfabf6c5a5aeb32b66d215ef",
			"sec-ch-ua": '"Not A(Brand";v="99", "Google Chrome";v="121", "Chromium";v="121"',
			"sec-ch-ua-mobile": '?1',
			"user-agent": 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36',
			"sec-ch-ua-platform": '"Android"'
		},
		timeout: {
			connect: 3000,
			request: 5000,
			response: 5000,
			socket: 4000,
			send: 5000,
			secureConnect: 5000,
			read: 5000,
			lookup: 5000,
		}
	}
}

const makeRequest = async (vid) => {
	const requestOptions = options(vid);
	const url = 'https://api.bilibili.tv/intl/gateway/web/playurl';
	const params = {
		s_locale: "id_ID",
		platform: 'html5_a',
		aid: vid,
		qn: 64,
		type: 1,
		device: "wap",
		tf: 0,
		spm_id: "bstar-web.ugc-video-detail.0.0",
		from_spm_id: "bstar-web.homepage.recommend.all"
	};

	try {
		const response = await axios.get(url, {
			params,
			headers: requestOptions.headers
		});
		return response.data;
	} catch (error) {
		console.error("Error making request:", error);
		throw error;
	}
};

bot.onText(/\/cek/, async (msg) => {
    const chatId = msg.chat.id;
    
	//const textAfterCek = match[1];
	//console.log("match > ", match);
	//bot.sendMessage(chatId, `Anda mengetik: ${textAfterCek}`);
	
	bot.sendMessage(chatId, 'Mohon Tunggu Sedang Cek Akun Bstation Apakah Sudah PREMIUM Atau Belum.');
	
    // https://www.bilibili.tv/v/page/premium-benefits/index.html
	// https://www.bilibili.tv/id/vip-benefits
	
	// mid=1971290613; DedeUserID=1971290613; DedeUserID__ckMd5=5cd0e460cad2918039586afe927132b5; SESSDATA=1fad3504,1731512002,88ade*5100f5; bili_jct=29a56853bfabf6c5a5aeb32b66d215ef
	// 'Cookie': textAfterCek,
	
	// COOKIES = YtCrash News = TIDAK PREMIUM
	// mid=1935471790; DedeUserID=1935471790; DedeUserID__ckMd5=d889c567f9c6ed7b76e168a38ec52790; SESSDATA=15f537e1%2C1731880011%2Cd8669%2A5100ae; bili_jct=af4b96646ad23e39d72d9303c1d1825e
	const headers = {
		'Origin': 'https://www.bilibili.tv',
		'Referer': `https://www.bilibili.tv/id/account/setting`,
		'Cookie': "mid=1935471790; DedeUserID=1935471790; DedeUserID__ckMd5=d889c567f9c6ed7b76e168a38ec52790; SESSDATA=15f537e1%2C1731880011%2Cd8669%2A5100ae; bili_jct=af4b96646ad23e39d72d9303c1d1825e",
		'sec-ch-ua': '"Not A(Brand";v="99", "Google Chrome";v="121", "Chromium";v="121"',
		'sec-ch-ua-mobile': '?1',
		'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36',
		'sec-ch-ua-platform': '"Android"'
	};
	
	axios.get("https://www.bilibili.tv/id/vip-benefits", {
		headers: headers
	})
	.then(async (response) => {
		console.log("response axios CEK PREMIUM URL : ", response.data);
		
		if (response.data.includes("vip_benefit_type:1")) {
			console.log("AKUN BSTATION PREMIUM");
			//bot.sendMessage(chatId, '*AKUN BSTATION PREMIUM*');
			
			
			
			// ================================================================================================
			let hasilres_cekpremiumbstation = response.data;
			// DEBUGGING RESPOND AXIOS
			// console.log(hasilres_judul);
			
			// Find the position of the title tag
			let NamaAkunBstationStart = hasilres_cekpremiumbstation.indexOf('(false,true,"') + '(false,true,"'.length;
			let NamaAkunBstationEnd = hasilres_cekpremiumbstation.indexOf('","https:', NamaAkunBstationStart);

			// Find the position of the title tag
			let ExpiredPremiumStart = hasilres_cekpremiumbstation.indexOf('vip_info:{is_vip:b,due_date:"') + 'vip_info:{is_vip:b,due_date:"'.length;
			let ExpiredPremiumEnd = hasilres_cekpremiumbstation.indexOf('",vip_benefit_type', ExpiredPremiumStart);


			// Extract the title
			let NamaAkunBstation = "";
			NamaAkunBstation = hasilres_cekpremiumbstation.substring(NamaAkunBstationStart, NamaAkunBstationEnd);
			console.log("NamaAkunBstation : ", NamaAkunBstation);
			
			// Extract the title
			let ExpiredPremium = "";
			ExpiredPremium = hasilres_cekpremiumbstation.substring(ExpiredPremiumStart, ExpiredPremiumEnd);
			ExpiredPremium = ExpiredPremium.replace(/\\u002F/g, "-"); // Mengganti "\\u002F" dengan "-"

			console.log("ExpiredPremium : ", ExpiredPremium);
			
			
			// ================================================================================================================================
			console.log("AKUN BSTATION PREMIUM");
			
			if (NamaAkunBstation.length > 200) {
				bot.sendMessage(chatId, `*"AKUN BSTATION PREMIUM"*`, { parse_mode: 'Markdown' });
			} else {
				bot.sendMessage(chatId, `==========================\n*DETAIL INFO AKUN BSTATION*\n==========================\n➡️ Nama Akun : ${NamaAkunBstation}\n➡️ Tipe Akun : *PREMIUM*\n➡️ Masa Premium : ${ExpiredPremium}\n==========================`, { parse_mode: 'Markdown' });
			}
			
			// ================================================================================================================================
			
			return;
			
		} else {
			console.log("AKUN BSTATION BELUM/TIDAK PREMIUM");
			//bot.sendMessage(chatId, '*AKUN BSTATION BELUM/TIDAK PREMIUM*');
			
			
			// ================================================================================================
			let hasilres_cekpremiumbstation = response.data;
			// DEBUGGING RESPOND AXIOS
			// console.log(hasilres_judul);
			
			// Find the position of the title tag
			let NamaAkunBstationStart = hasilres_cekpremiumbstation.indexOf('(false,"",true,0,"') + '(false,"",true,0,"'.length;
			let NamaAkunBstationEnd = hasilres_cekpremiumbstation.indexOf('","https:', NamaAkunBstationStart);

			// Find the position of the title tag
			let ExpiredPremiumStart = hasilres_cekpremiumbstation.indexOf('vip_info:{is_vip:b,due_date:"') + 'vip_info:{is_vip:b,due_date:"'.length;
			let ExpiredPremiumEnd = hasilres_cekpremiumbstation.indexOf('",vip_benefit_type', ExpiredPremiumStart);


			// Extract the title
			let NamaAkunBstation = "";
			NamaAkunBstation = hasilres_cekpremiumbstation.substring(NamaAkunBstationStart, NamaAkunBstationEnd);
			console.log("NamaAkunBstation : ", NamaAkunBstation);
			
			// ================================================================================================================================
			console.log("AKUN BSTATION BELUM/TIDAK PREMIUM");
			
			if (NamaAkunBstation.length > 200) {
				bot.sendMessage(chatId, `*"AKUN BSTATION BELUM/TIDAK PREMIUM"*`, { parse_mode: 'Markdown' });
			} else {
				bot.sendMessage(chatId, `==========================\n*AKUN BSTATION PREMIUM*\n==========================\n➡️ Nama Akun : ${NamaAkunBstation}\n➡️ Tipe Akun : *Akun Biasa*\n➡️ Masa Premium : -\n==========================`, { parse_mode: 'Markdown' });
			
			}
			// ================================================================================================================================
			
			
			return;
		}
		
	})
	.catch(error => {
		console.error('Error:', error);
	});
	
	
});

// Tangani pesan '/start'
bot.onText(/\/login/, async (msg) => {
	const chatId = msg.chat.id;
	bot.sendMessage(chatId, 'Mohon Tunggu Sebentar,\nSedang Request Login\nKe Server Bstation');
	
    
	const authUrl = 'https://passport.bilibili.tv/x/intl/passport-login/qrcode/auth/url';
	const fetchUrl = 'https://passport.bilibili.tv/x/intl/passport-login/qrcode/auth/fetch'
	
	const vid = 4791209637315074; // Ganti dengan ID video yang sesuai

	const headers = {
		'Origin': 'https://www.bilibili.tv',
		'Referer': `https://www.bilibili.tv/id/video/${vid}?bstar_from=bstar-web.homepage.recommend.all`,
		'Cookie': 'mid=1971290613; DedeUserID=1971290613; DedeUserID__ckMd5=5cd0e460cad2918039586afe927132b5; SESSDATA=1fad3504,1731512002,88ade*5100f5; bili_jct=29a56853bfabf6c5a5aeb32b66d215ef',
		'sec-ch-ua': '"Not A(Brand";v="99", "Google Chrome";v="121", "Chromium";v="121"',
		'sec-ch-ua-mobile': '?1',
		'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36',
		'sec-ch-ua-platform': '"Android"'
	};

	let searchParams = {
		's_locale': 'id_ID', // Ganti dengan lokasi yang sesuai
		'platform': 'web',
		'ticket': undefined
	};

	// ================================================================
	axios.get(authUrl, {
		headers: headers,
		params: searchParams
	})
	.then(async (response) => {
		console.log("response axios auth url : ", response.data);
		
		let URL_QR_LOGIN = response.data.data.qr_url;
		console.log("response 'response.data.data.qr_url' / 'URL_QR_LOGIN' : ", URL_QR_LOGIN);
		
		 // Mengambil URL QR dari sumber yang diberikan
		const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?data=${URL_QR_LOGIN}&size=400x400`;

		try {
			// Mengambil gambar QR dari URL
			const response = await axios.get(qrUrl, { responseType: 'arraybuffer' });
			console.log("response gambar QR : ", response.data);
			
			// Mengirim gambar ke pengguna
			//await bot.sendMessage(chatId, `*SCAN CODE QR LOGIN INI*\n${URL_QR_LOGIN}`, { parse_mode: 'Markdown' });
			await bot.sendPhoto(chatId, Buffer.from(response.data), { 
				caption: `*SCAN CODE QR LOGIN INI*\n\n${URL_QR_LOGIN}`,
				parse_mode: 'Markdown'
			});

		} catch (error) {
			console.error('Error fetching or sending QR code:', error);
			// Memberi tahu pengguna jika terjadi kesalahan
			bot.sendMessage(chatId, 'Maaf, terjadi kesalahan saat mengambil atau mengirim QR code.');
		}
		
		
		const ticket = response.data.data.qr_url.split('=')[1]; // Mengambil nilai ticket dari URL
		console.log("ticket 1 : ", ticket);
		
		let searchParams = {
			's_locale': 'id_ID',
			'platform': 'web',
			'ticket': ticket
		};
		
		let waktu_tunggu = 1;
		let sukseslogin = "";
		let expired = "";
		
		while (true) {
			// Sekarang Anda dapat melakukan permintaan HTTP lain dengan searchParams yang diperbarui
			// Misalnya:
			axios.get(fetchUrl, {
				headers: headers,
				params: searchParams
			})
			.then(async (response) => {
				// { code: 10018101, message: '10018101', ttl: 1 }
				// 10018101 = Belum Di Scan / Menunggu di scan.
				// 10018100 = QR code has expired
				// 10018102 = QR has been scanned...waiting to get approval!!!
				// 0 = Sukses Login & ada data di "data"
				console.log(response.data); // Menampilkan respons dari permintaan
				
				
				// 10018101 = Belum Di Scan / Menunggu di scan.
				if (response.data.code === 10018101) {
					console.log("Belum Di Scan / Menunggu di scan."); 
					bot.sendMessage(chatId, "Belum Di Scan / Menunggu di scan.");
					
				// 10018100 = QR code has expired
				} else if (response.data.code === 10018100) {
					console.log("QR code has expired"); 
					bot.sendMessage(chatId, "QR code has expired");
					
					expired = true;
					
				// 10018102 = QR has been scanned...waiting to get approval!!!
				} else if (response.data.code === 10018102) {
					console.log("QR has been scanned...waiting to get approval!!!"); 
					//bot.sendMessage(chatId, "QR SUDAH BERHBASIL DI SCAN\NLangkah Terakhir Silahkan Klik Confirm");
					await bot.sendMessage(chatId, `*QR SUDAH BERHASIL DI SCAN*\n\nLangkah Terakhir Silahkan Klik Confirm`, { parse_mode: 'Markdown' });
					
				// 0 = Sukses Login & ada data di "data"	
				} else if (response.data.code === 0) {
					console.log("Sukses Login & ada data di data"); 
					bot.sendMessage(chatId, "Sukses Login & ada data di data");
					
					const mid = response.data.data.mid
					const regCookie = /(\w+)=([^&]+)/g;
					const creds = response.data.data.go_url.match(regCookie)
					const cookies = `mid=${mid}; ${creds[0]}; ${creds[1]}; ${creds[3]}; ${creds[4]}`
					
					console.log("DATA mid : ", mid);
					console.log("DATA cookies : ", cookies); 
					
					await bot.sendMessage(chatId, cookies);
					await bot.sendMessage(chatId, `Data Cookies : ${cookies}`);
					
					sukseslogin = true;
				}
				
				
			})
			.catch(error => {
				console.error('Error:', error);
			});
			
			await sleep(1000); // Menunggu selama 1000 milidetik (1 detik)
			waktu_tunggu++;
			console.log("waktu_tunggu : ", waktu_tunggu);
			
			if (waktu_tunggu === 10000) break
			if (sukseslogin === true) break
			if (expired === true) break
		}
		
		console.log("waktu_tunggu last : ", waktu_tunggu);
		
	})
	.catch(error => {
		console.error('Error:', error);
	});
	// ================================================================
});

// Tangani pesan '/start'
bot.onText(/\/start/, async (msg) => {
	const chatId = msg.chat.id;
	bot.sendMessage(chatId, 'Hallo! Bot sedang online.');
	//getVideoAndAudioURL(4791333250793476);
    
    const cekcekcek = await axios.get("https://webhook.site/82709989-7cd3-4fea-bbd7-af51c516781a");
    console.log("cekcekcek : ", cekcekcek.data);
    
    // Example usage
    let videoIdBstation = 2041464768
    console.log("videoIdBstation : ", videoIdBstation)
    makeRequest(videoIdBstation)
        .then(async (data) => {
           console.log("Response data:", data);

            //console.log("Response data ssss:", data.data.playurl.video);
			
        	if (data.message === "版权地区受限") {
                console.log("message: '版权地区受限' = Wilayah hak cipta dibatasi / IP TERBLOCK");
                bot.sendMessage(chatId, "message: '版权地区受限' = Wilayah hak cipta dibatasi / IP TERBLOCK");
                return;
            }
        
            const recons_bstationvideo = data.data.playurl.video.map(response => {
                const metadata_video = response.video_resource
                return {
                    url: metadata_video.url,
                    bitrate: response.stream_info.desc_words,
                    mimetype: metadata_video.mime_type,
                    codecs: metadata_video.codecs,
                    audio: response.audio_quality,
                    size: metadata_video.size
                    }
            })
            const audio_bstationvideo = data.data.playurl.audio_resource.map(response => {
                return {
                    url: response.url,
                    quality: response.quality,
                    mimetype: response.mime_type,
                    codecs: response.codecs,
                    size: response.size
                }
            })
            const videoList = recons_bstationvideo.filter(m => m.codecs.includes('hev'))

            const smallestAudio = audio_bstationvideo.reduce((prev, current) => {
              return (prev.size < current.size) ? prev : current;
            });

            //console.log("URL audio dengan size terendah:", smallestAudio.url);


            //console.log("audio :", audio_bstationvideo);
            //console.log("video :", videoList);

            const videoQualities = [720, 480, 360];

            let URL_VIDEO = '';
            let Quality_VIDEO = '';

            for (const quality of videoQualities) {
              const video = videoList.find(v => v.bitrate.includes(`${quality}P`));

              // Lakukan sesuatu jika URL video tidak kosong atau tidak null
              if (video.url) {
                URL_VIDEO = video.url;
                Quality_VIDEO = `${quality}P`;
                //console.log(`URL video terpilih - ${Quality_VIDEO} : `, URL_VIDEO);
                break;
              }
            }

            let URL_AUDIO = smallestAudio.url;
            console.log(`URL VIDEO terpilih - ${Quality_VIDEO} : `, URL_VIDEO);
			bot.sendMessage(chatId, URL_VIDEO);
            console.log(`\n`);
            console.log(`URL audio dengan size terendah : `, URL_AUDIO);
			bot.sendMessage(chatId, URL_AUDIO);
        })
        .catch(error => {
            console.error("Request error:", error);
            return;
        });
    
});

console.log('Bot sedang berjalan...');
